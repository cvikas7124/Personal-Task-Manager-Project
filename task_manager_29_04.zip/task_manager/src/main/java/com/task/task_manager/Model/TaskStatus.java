package com.task.task_manager.Model;

public enum TaskStatus {
  PENDING,COMPLETED,ONGOING
}
