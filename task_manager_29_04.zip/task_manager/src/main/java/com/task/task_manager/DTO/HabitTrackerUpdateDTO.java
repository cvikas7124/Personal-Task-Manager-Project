package com.task.task_manager.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record HabitTrackerUpdateDTO(
@NotNull(message = "ID is required")    
Long id,
@NotBlank(message = "Title is required")
String title,
@NotBlank(message = "Description is required") 
String status) {

}
