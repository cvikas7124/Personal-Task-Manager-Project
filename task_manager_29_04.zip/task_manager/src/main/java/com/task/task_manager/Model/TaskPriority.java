package com.task.task_manager.Model;

public enum TaskPriority {
     LOW,MEDIUM,HIGH
}
