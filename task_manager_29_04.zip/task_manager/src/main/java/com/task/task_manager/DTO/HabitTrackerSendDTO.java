package com.task.task_manager.DTO;


public record HabitTrackerSendDTO(Long id,String title,String status) {

}
