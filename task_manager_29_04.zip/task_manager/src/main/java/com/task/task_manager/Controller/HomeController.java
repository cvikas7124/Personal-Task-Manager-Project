package com.task.task_manager.Controller;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.task.task_manager.DTO.LoginDTO;
import com.task.task_manager.DTO.UserRegisterDTO;
import com.task.task_manager.Exception.UserNotFoundException;
import com.task.task_manager.Model.MailBody;
import com.task.task_manager.Model.User;
import com.task.task_manager.Repo.UserRepo;
import com.task.task_manager.Service.EmailService;
import com.task.task_manager.Service.JwtService;
import com.task.task_manager.Service.UserService;

import jakarta.validation.Valid;


@RestController
public class HomeController {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    AuthenticationManager authenticationManager;
    @Autowired
    private JwtService jwtService; 
    @Autowired
    private UserService userService;

    @Autowired
    private EmailService emailService;


    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody UserRegisterDTO dto)
    {
        
        String emailDomain = dto.email().substring(dto.email().lastIndexOf("@") + 1);
         if (!emailDomain.equals("gmail.com")) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Please provide a valid Gmail address");
         }
        if(userRepo.findByUsername(dto.username()).isPresent())
        {
             return ResponseEntity.status(HttpStatus.CONFLICT).body("UserName Already Exists");
        }
        if(userRepo.findByEmail(dto.email()).isPresent())
        {
             return ResponseEntity.status(HttpStatus.CONFLICT).body("Email Already Exists");
        }

        User user= new User();
        user.setUsername(dto.username());
        user.setEmail(dto.email());
        user.setPassword(dto.password());
         userService.saveUser(user);
         MailBody mailBody = MailBody.builder()
            .to(dto.email())
            .text("<!DOCTYPE html>" +
                    "<html>" +
                    "<head>" +
                    "<style>" +
                    "  body { font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px; }" +
                    "  .container { background-color: #ffffff; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }" +
                    "  h2 { color: #4CAF50; }" +
                    "  p { font-size: 16px; color: #333333; }" +
                    "</style>" +
                    "</head>" +
                    "<body>" +
                    "  <div class='container'>" +
                    "    <h2>Welcome to TickIT!</h2>" +
                    "    <p>Hi "+ dto.username()+",</p>" +
                    "    <p>Your registration was successful. We're excited to have you on board!</p>" +
                    "    <p>Start managing your tasks more efficiently today.</p>" +
                    "    <p>Cheers,<br>TickIT Team</p>" +
                    "  </div>" +
                    "</body>" +
                    "</html>"
            )
            .subject("Registration Successful")
            .build();
        emailService.sendHtmlMessage(mailBody);
         return ResponseEntity.ok("Added Successfully");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginDTO loginDTO) {
        try{
         authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginDTO.username(),
          loginDTO.password()));
            User user=userRepo.findByUsername(loginDTO.username()).orElseThrow(()->new UserNotFoundException("Enter Valid email"));
            String newAccessToken=jwtService.generateAccessToken(loginDTO.username());
            String newRefreshToken=jwtService.generateRefreshToken(loginDTO.username());
            Map<String, String> tokenMap = new HashMap<>();
            tokenMap.put("accessToken", newAccessToken);
            tokenMap.put("username",loginDTO.username());
            tokenMap.put("email", user.getEmail());
            
            ResponseCookie cookie=ResponseCookie.from("refreshToken",newRefreshToken)
            .httpOnly(true)
            .secure(false)
            .path("/refresh")
            .maxAge(Duration.ofDays(1))
            .sameSite("Lax")
            .build();

              return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE,cookie.toString()).body(tokenMap);
        }
        catch(BadCredentialsException e)
        {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Invaild username password");
        }
    }

   @PostMapping("/refresh")
public ResponseEntity<?> refresh(@CookieValue(name = "refreshToken", required = false) String refreshToken) {
    if (refreshToken == null || refreshToken.isEmpty()) {
        return ResponseEntity.badRequest().body("you have logged out . Pls login");
    }

    try {
        String username = jwtService.extractUserName(refreshToken);

        if (jwtService.isTokenValid(refreshToken, username)) {
            String newAccessToken = jwtService.generateAccessToken(username);
            String newRefreshToken = jwtService.generateRefreshToken(username); // optional rotation

            Map<String, String> tokenMap = new HashMap<>();
            tokenMap.put("accessToken", newAccessToken);

            // Optionally rotate refresh token and set new cookie
            ResponseCookie cookie = ResponseCookie.from("refreshToken", newRefreshToken)
                    .httpOnly(true)
                    .secure(false) // set false for localhost without HTTPS
                    .path("/refresh")
                    .maxAge(Duration.ofDays(1))
                    .sameSite("Lax")
                    .build();

            return ResponseEntity.ok()
                    .header(HttpHeaders.SET_COOKIE, cookie.toString())
                    .body(tokenMap);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid or expired refresh token.Please log in again.");
        }
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid refresh token. Please log in again.");
    }
}

@PostMapping("/log")
public ResponseEntity<?> logout() {
    ResponseCookie deleteCookie = ResponseCookie.from("refreshToken", "")
            .httpOnly(true)
            .secure(false)
            .path("/refresh") 
            .maxAge(0)
            .sameSite("Lax")
            .build();

    return ResponseEntity.ok()
            .header(HttpHeaders.SET_COOKIE, deleteCookie.toString())
            .body("Logged out successfully");
}

}
